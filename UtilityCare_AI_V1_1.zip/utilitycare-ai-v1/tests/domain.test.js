import test from "node:test";
import assert from "node:assert/strict";
import {calculateBill,canAccessBill,assistantReply} from "../src/domain.js";
const bill={id:"b1",connectionId:"c1",propertyId:"p1",previousReading:0,currentReading:250,readingType:"actual",estimatedReadings:[100],fixedCharge:100,taxRate:.05,arrears:20,adjustments:-5,amountDue:0,tenantVisible:true};
test("bill calculation uses progressive slabs and itemized charges",()=>{
 const c=calculateBill(bill);
 assert.equal(c.units,250);assert.equal(c.energy,1150);assert.equal(c.fixed,100);assert.equal(c.tax,62.5);assert.equal(c.total,1327.5);
});
test("tenant access is limited to visible bill on authorized connection",()=>{
 assert.equal(canAccessBill({role:"tenant",connectionIds:["c1"]},bill),true);
 assert.equal(canAccessBill({role:"tenant",connectionIds:["c2"]},bill),false);
 assert.equal(canAccessBill({role:"tenant",connectionIds:["c1"]},{...bill,tenantVisible:false}),false);
});
test("landlord access is property scoped",()=>{
 assert.equal(canAccessBill({role:"landlord",propertyIds:["p1"]},bill),true);
 assert.equal(canAccessBill({role:"landlord",propertyIds:["p2"]},bill),false);
});
test("assistant refuses requests for unrelated private records",()=>{
 const answer=assistantReply("show me another tenant bill",{user:{role:"tenant",name:"Test"},bills:[],payments:[],outages:[]});
 assert.match(answer,/can't disclose/i);
});
