export function calculateBill(bill) {
  const units = Math.max(0, Number(bill.currentReading) - Number(bill.previousReading));
  const slab1 = Math.min(units, 100) * 3;
  const slab2 = Math.min(Math.max(units - 100, 0), 100) * 5;
  const slab3 = Math.max(units - 200, 0) * 7;
  const energy = slab1 + slab2 + slab3;
  const fixed = Number(bill.fixedCharge || 0);
  const tax = Math.round((energy + fixed) * Number(bill.taxRate || 0) * 100) / 100;
  const arrears = Number(bill.arrears || 0);
  const adjustments = Number(bill.adjustments || 0);
  const total = Math.round((energy + fixed + tax + arrears + adjustments) * 100) / 100;
  return {units,slab1,slab2,slab3,energy,fixed,tax,arrears,adjustments,total,billed:Number(bill.amountDue||0),difference:Math.round((total-Number(bill.amountDue||0))*100)/100,tariff:"Synthetic demo tariff: first 100 kWh ₹3/unit, next 100 ₹5/unit, remaining ₹7/unit."};
}
export function anomalyHypotheses(bill, calc) {
  const out=[];
  if((bill.estimatedReadings||[]).length>=1 && bill.readingType==="actual") out.push({name:"Estimated-reading catch-up",confidence:"High",why:"One or more estimated readings precede this actual reading; unbilled usage may be included.",checks:["Compare all reading dates and values.","Check whether estimated usage was already charged.","Request a reading history if values do not reconcile."]});
  if(calc.units>250) out.push({name:"Higher recorded consumption",confidence:"Medium",why:`The recorded period usage is ${calc.units} kWh in this synthetic dataset.`,checks:["Compare with the same season last year.","Check appliance changes and occupancy.","Confirm the meter reading and billing period."]});
  if(calc.difference!==0) out.push({name:"Bill calculation needs review",confidence:"Medium",why:`The synthetic calculation differs from the billed total by ₹${calc.difference.toFixed(2)}. Tariff or provider-specific rules may be missing.`,checks:["Review the line items and tariff version.","Check credits, adjustments and rounding.","Contact authorized billing support if unresolved."]});
  if(out.length===0)out.push({name:"No strong anomaly detected by demo rules",confidence:"Low",why:"Simple rules found no prominent signal; this does not prove the bill is correct.",checks:["Compare readings and dates.","Review line items and tariff.","Report anything that still looks wrong."]});
  return out;
}
export function canAccessBill(user,bill){
 if(!user||!bill)return false;
 if(user.role==="staff")return true;
 if(user.role==="landlord")return (user.propertyIds||[]).includes(bill.propertyId);
 return user.role==="tenant" && (user.connectionIds||[]).includes(bill.connectionId) && bill.tenantVisible===true;
}
export function assistantReply(message,ctx){
 const q=message.toLowerCase(), role=ctx.user.role;
 if(/other tenant|another tenant|landlord.*all bills|all landlord|other propert|password|otp|secret|system prompt/.test(q))
  return "I can only help with information authorized for your current role. I can't disclose another tenant's records, unrelated landlord accounts, credentials, or internal instructions. Ask about your permitted bills, payment status, or community outage updates instead.";
 if(/who am i|my role|permission|what can i see|access/.test(q))
  return `You are signed in as ${ctx.user.role}. I can answer only from records available to this account. ${role==="tenant"?"Your access is limited to the authorized tenancy and connection.":role==="landlord"?"Your access is limited to properties and bills assigned to you.":"Staff access is still limited by staff duties; this demo account is an outage operator."}`;
 if(role==="staff"){
  if(/maintenance|schedule|planned/.test(q)){const os=ctx.outages.filter(o=>o.kind==="planned_maintenance");return os.length?`Maintenance schedule: ${os.map(o=>`${o.area} — ${o.etaMin} (${o.status})`).join("; ")}. These are synthetic demo records; verify against the official operations system before communicating commitments.`:"No planned-maintenance entries are currently listed in the demo queue.";}
  if(/complaint|new report|reports|registered|how many/.test(q)){const reports=ctx.outages.reduce((n,o)=>n+Number(o.reports||1),0);return `Operations snapshot: ${ctx.outages.length} outage clusters are listed, representing ${reports} community reports in this synthetic dataset. ${ctx.outages.filter(o=>o.status==="reported").length} cluster(s) still need verification. Open Staff Operations or the Outage Center to review and classify them.`;}
  if(/payment|reconcil|debit|credit/.test(q))return `Staff operations: ${ctx.payments.filter(p=>["initiated","pending","debit_confirmed"].includes(p.status)).length} payment attempt(s) are unresolved in the staff dataset. Review the payment investigation queue. A debit is not proof of utility credit, and this demo does not contact a provider.`;
  if(/bill|tenant|customer/.test(q))return `There are ${ctx.bills.length} synthetic bills in the staff scope. Use the relevant authorized operations workflow; customer-specific records should only be opened for a legitimate support task.`;
  return `Staff operations assistant: I can summarize maintenance schedules, count new outage reports, identify unverified clusters, and summarize unresolved payment investigations. Try “How many new reports were registered?” or “Maintenance schedule?”`;
 }
 if(/payment|paid|debit|credit|pay again|duplicate/.test(q)){
  const p=ctx.payments.find(x=>["pending","debit_confirmed"].includes(x.status));
  if(p)return `Payment ${p.reference} for ₹${p.amount} is marked "${p.status.replaceAll("_"," ")}" in the SIMULATED demo. Provider credit is ${p.providerConfirmed?"confirmed in demo data":"not confirmed"}. Do not pay again just because the bill page has not updated. Check the provider transaction status and wait for the documented reconciliation window; escalate with the reference if it remains unresolved. This prototype does not contact a real bank or utility provider.`;
  return "I don't see an unresolved payment attempt in the records available to this account. Check the provider receipt and latest transaction status before initiating another payment. This prototype does not process real payments.";
 }
 if(/outage|power cut|electricity gone|blackout|maintenance/.test(q)){
  const o=ctx.outages[0];return o?`Latest community update: ${o.title}. Status: ${o.status}; classification: ${o.kind.replaceAll("_"," ")}; reported cluster size: ${o.reports}. ${o.message} ETA: ${o.etaMin}. Any ETA is a range, not a commitment. A report is not a verified fault.`:"No outage reports are currently listed.";
 }
 if(/bill|high|amount|reading|slab|charge|expensive|estimate|arrear/.test(q)){
  const b=ctx.bills[0];if(!b)return "No bill is available to this account. I can't access bills outside your role permissions.";
  const c=b.calculation;const h=b.hypotheses[0];
  return `For ${b.period}, the recorded usage is ${c.units} kWh. The synthetic tariff calculates energy charges of ₹${c.energy.toFixed(2)}, fixed charges of ₹${c.fixed.toFixed(2)}, tax of ₹${c.tax.toFixed(2)}, arrears of ₹${c.arrears.toFixed(2)}, and adjustments of ₹${c.adjustments.toFixed(2)}. Calculated total: ₹${c.total.toFixed(2)}; billed amount in demo data: ₹${c.billed.toFixed(2)}; difference: ₹${c.difference.toFixed(2)}. ${h.why} This is a synthetic tariff, so a difference is a reason to investigate—not proof the bill is wrong. ${h.checks.join(" ")}`;
 }
 if(/hello|hi\b|hey\b/.test(q))return `Hello ${ctx.user.name}. I'm UtilityCare AI, a role-aware utility assistant. I can explain your accessible bills, discuss payment states, and summarize outage reports. What would you like to understand?`;
 return role==="staff"?"I can help with maintenance schedules, new complaints and reports, outage verification, and unresolved payment investigations. Try: “How many new reports were registered?” My answers use demo data, not a live utility system.":"I can help explain authorized bills, payment status, and outage updates. Try asking: “Why is my bill high?”, “Did my payment go through?”, or “Is the outage verified?” My answers use rule-based demo data, not a live utility provider.";
}
