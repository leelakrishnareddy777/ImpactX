# UtilityCare AI — Version 1

A runnable, dependency-free website prototype for IMPACTX 2026 Challenge 18.

## Features
- Role login: Staff or User; User branches into Landlord and Tenant.
- Server-enforced resource scoping for the demo API.
- Bill breakdown with configurable synthetic slab tariff and estimated-reading catch-up explanation.
- Payment state timeline and duplicate-payment guard.
- Community outage reports, clustered demo updates, planned-maintenance reclassification for staff.
- Role-aware assistant by text, with optional browser speech-to-text and text-to-speech.
- Staff operations view and audit events.
- Responsive design; no build step or external package install needed.

## Requirements
Node.js 18+.

## Run
```bash
npm start
```
Open http://localhost:3000

## Demo accounts
Choose a role on the login screen and use the demo identity:
- Staff: `staff@demo.local` / `Demo123!`
- Landlord: `landlord@demo.local` / `Demo123!`
- Tenant: `tenant@demo.local` / `Demo123!`

These are seeded demo credentials only. Do not use them in production. The app is a local prototype and uses an in-memory demo store; restarting the server resets changes.

## Voice
Press the microphone button in a supported browser (Chrome generally works best) and grant microphone permission. Speech recognition depends on browser support and may send audio to the browser vendor's speech service. Text input always works. Voice responses use the browser's speech synthesis.

## Security scope
This is a prototype, not a production utility billing or payment system. The server enforces role and resource checks for included API routes, but the demo authentication uses a simple signed session cookie and fixed demo users. Before production: use a managed identity provider, HTTPS, CSRF protections, rate limiting, database-backed sessions, strong secrets, MFA for staff, formal consent workflows, provider payment APIs/webhooks, secrets management, retention policies, accessibility/security testing, and legal review. Payment outcomes and outage statuses are labelled simulated. No real payments are processed.

## API overview
- `POST /api/login` — role-specific demo login
- `POST /api/logout`
- `GET /api/me`
- `GET /api/dashboard`
- `GET /api/bills`
- `GET /api/payments`
- `POST /api/payments/:id/reconcile` — staff only, demo transition
- `GET /api/outages`
- `POST /api/outages/report`
- `POST /api/outages/:id/verify` — outage staff only
- `POST /api/assistant` — role-scoped answers
- `GET /api/audit` — staff only

## Tests
```bash
npm test
```
Tests cover bill calculation and basic authorization helper behavior.


## V1.1 enhancements
- Role-specific assistant prompts: staff gets maintenance, complaint/report counts, outage verification, and payment-investigation questions; landlord/tenant get bill, payment, and outage help.
- Voice input using the browser Speech Recognition API and spoken replies using SpeechSynthesis. English is the default; Hindi recognition is offered when supported by the browser, but Hindi AI response generation is not implemented.
- Landlord Tenants & Meters page: add tenant name, email, phone, meter number, property, move-in date, and bill visibility start month. Tenant access is tied to one connection and only periods on/after the selected month are returned.
- Synthetic monthly history is generated for new meter connections so the month filter can be demonstrated.
- Simulated checkout with initiated/pending/debit-confirmed/credit-reconciled/failed/reversed states, unresolved-payment duplicate guarding, and clear no-real-money disclaimers.

**Demo limitations:** Records live in memory and reset when the server restarts. New tenant demo password is `Tenant@123`; no email is sent. Do not deploy this prototype with real customer data. Before production, implement persistent storage, secure password hashing, password reset, real authorization tests, CSRF protections, provider integrations, and privacy/security review.
