import http from "node:http";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { calculateBill, anomalyHypotheses, canAccessBill, assistantReply } from "./src/domain.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const SECRET = process.env.SESSION_SECRET || "local-demo-secret-change-before-production";
const mime = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json; charset=utf-8",".svg":"image/svg+xml"};

const users = [
  {id:"u-staff",email:"staff@demo.local",password:"Demo123!",name:"Avery Staff",role:"staff",staffRole:"outage_operator"},
  {id:"u-landlord",email:"landlord@demo.local",password:"Demo123!",name:"Morgan Landlord",role:"landlord",propertyIds:["p-101","p-102"]},
  {id:"u-tenant",email:"tenant@demo.local",password:"Demo123!",name:"Jamie Tenant",role:"tenant",propertyIds:["p-101"],connectionIds:["c-101"],tenancyId:"ten-101"}
];
const bills = [
 {id:"b-101",connectionId:"c-101",propertyId:"p-101",period:"Sep 2026",dueDate:"2026-11-05",previousReading:1200,estimatedReadings:[1250,1300],currentReading:1500,readingType:"actual",fixedCharge:100,taxRate:0.05,arrears:250,adjustments:-20,amountDue:2600,status:"unpaid",tenantVisible:true},
 {id:"b-102",connectionId:"c-101",propertyId:"p-101",period:"Aug 2026",dueDate:"2026-10-05",previousReading:1150,estimatedReadings:[],currentReading:1200,readingType:"estimated",fixedCharge:100,taxRate:0.05,arrears:0,adjustments:0,amountDue:330,status:"paid",tenantVisible:true},
 {id:"b-201",connectionId:"c-201",propertyId:"p-102",period:"Sep 2026",dueDate:"2026-11-05",previousReading:800,estimatedReadings:[],currentReading:910,readingType:"actual",fixedCharge:120,taxRate:0.05,arrears:0,adjustments:35,amountDue:900,status:"unpaid",tenantVisible:false}
];
const payments = [
 {id:"pay-101",billId:"b-101",connectionId:"c-101",amount:2600,status:"debit_confirmed",attempts:1,reference:"DEMO-TXN-78314",createdAt:"2026-10-24T09:52:00+05:30",providerConfirmed:false},
 {id:"pay-102",billId:"b-102",connectionId:"c-101",amount:330,status:"credit_reconciled",attempts:1,reference:"DEMO-TXN-77102",createdAt:"2026-10-05T12:30:00+05:30",providerConfirmed:true}
];
const outages = [
 {id:"out-1",title:"Power interruption near Lake Road",area:"Lake Road / Ward 12",feeder:"FDR-12",transformer:"TX-12A",reports:7,status:"reported",kind:"unknown",etaMin:"2–4 hours",updatedAt:"10:05 AM",message:"Community reports are being checked. This is not yet a verified fault."},
 {id:"out-2",title:"Planned maintenance — Market Street",area:"Market Street / Ward 8",feeder:"FDR-08",transformer:"TX-08B",reports:12,status:"verified",kind:"planned_maintenance",etaMin:"11:30 AM–1:00 PM",updatedAt:"9:40 AM",message:"Scheduled maintenance confirmed in this synthetic demo."}
];
const tenants = [{id:"ten-101",name:"Jamie Tenant",email:"tenant@demo.local",phone:"9876543210",connectionId:"c-101",propertyId:"p-101",meterNumber:"MTR-1001",startMonth:"2026-08",moveInDate:"2026-08-01",landlordId:"u-landlord"}];
const audit = [];
const sessions = new Map();
const serverStarted = new Date().toISOString();

function sign(value){ return crypto.createHmac("sha256",SECRET).update(value).digest("hex"); }
function makeToken(userId){ const raw = `${userId}.${Date.now()}.${crypto.randomBytes(12).toString("hex")}`; return `${Buffer.from(raw).toString("base64url")}.${sign(raw)}`; }
function cookieToken(req){ const c = req.headers.cookie || ""; const m = c.match(/(?:^|;\s*)uc_session=([^;]+)/); return m?.[1] || ""; }
function getUser(req){
  const token = cookieToken(req); if(!token) return null;
  const [encoded, sig] = token.split("."); if(!encoded || !sig) return null;
  let raw; try { raw = Buffer.from(encoded,"base64url").toString(); } catch { return null; }
  if(sign(raw)!==sig) return null;
  const userId = raw.split(".")[0]; return users.find(u=>u.id===userId) || null;
}
function publicUser(u){ return u ? {id:u.id,name:u.name,email:u.email,role:u.role,staffRole:u.staffRole || null} : null; }
function json(res,status,data,headers={}){ res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store",...headers}); res.end(JSON.stringify(data)); }
function fail(res,status,error){ json(res,status,{error}); }
async function body(req){ let s=""; for await (const chunk of req) { s+=chunk; if(s.length>1e6) throw new Error("Body too large"); } return s ? JSON.parse(s) : {}; }
function log(u,action,resource,allowed=true){ audit.unshift({id:crypto.randomUUID(),at:new Date().toISOString(),actor:u?.email || "anonymous",role:u?.role || "none",action,resource,allowed}); if(audit.length>250)audit.pop(); }
function userBills(u){
 if(u.role==="staff") return bills;
 if(u.role==="landlord") return bills.filter(b=>u.propertyIds.includes(b.propertyId));
 const t=tenants.find(x=>x.email===u.email); const start=t?.startMonth||"0000-00";
 return bills.filter(b=>u.connectionIds.includes(b.connectionId) && b.tenantVisible && periodKey(b.period)>=start);
}
function userPayments(u){ const ids=new Set(userBills(u).map(b=>b.id)); return u.role==="staff" ? payments : payments.filter(p=>ids.has(p.billId)); }
function userOutages(){ return outages; }
function authorized(req,res,roles=null){
 const u=getUser(req); if(!u){fail(res,401,"Please sign in.");return null;}
 if(roles && !roles.includes(u.role)){log(u,"DENY",req.url,false);fail(res,403,"Your role does not have permission for this action.");return null;}
 return u;
}
function periodKey(period){const [mon,year]=String(period||"").split(" ");const m={Jan:"01",Feb:"02",Mar:"03",Apr:"04",May:"05",Jun:"06",Jul:"07",Aug:"08",Sep:"09",Oct:"10",Nov:"11",Dec:"12"}[mon]||"01";return `${year||"0000"}-${m}`;}
function safeBill(b){ const calc=calculateBill(b); return {...b,calculation:calc,hypotheses:anomalyHypotheses(b,calc)}; }

const app = http.createServer(async (req,res)=>{
 const url = new URL(req.url,"http://localhost");
 if(req.method==="GET" && url.pathname==="/api/health") return json(res,200,{ok:true,app:"UtilityCare AI",version:"1.0.0",mode:"SIMULATED"});
 if(req.method==="POST" && url.pathname==="/api/login"){
  try{
   const data=await body(req); const u=users.find(x=>x.email.toLowerCase()===String(data.email||"").toLowerCase() && x.password===data.password && x.role===data.role);
   if(!u){log(null,"LOGIN_FAILED",data.role||"unknown",false);return fail(res,401,"Demo login did not match. Use the demo credentials shown on the login page.");}
   const token=makeToken(u.id); log(u,"LOGIN","session");
   return json(res,200,{user:publicUser(u),demo:true},{ "Set-Cookie":`uc_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800` });
  }catch{return fail(res,400,"Invalid request.");}
 }
 if(req.method==="POST" && url.pathname==="/api/logout"){ const u=getUser(req); if(u)log(u,"LOGOUT","session"); return json(res,200,{ok:true},{ "Set-Cookie":"uc_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0" });}
 if(req.method==="GET" && url.pathname==="/api/me"){ const u=getUser(req); return json(res,200,{user:publicUser(u),mode:"SIMULATED"}); }
 if(req.method==="GET" && url.pathname==="/api/dashboard"){
  const u=authorized(req,res); if(!u)return;
  const bs=userBills(u), ps=userPayments(u);
  return json(res,200,{user:publicUser(u),billCount:bs.length,unpaid:bs.filter(b=>b.status==="unpaid").length,pendingPayments:ps.filter(p=>["pending","debit_confirmed"].includes(p.status)).length,outageCount:outages.length,bills:bs.slice(0,3).map(safeBill),outages:outages.map(o=>({...o}))});
 }
 if(req.method==="GET" && url.pathname==="/api/tenants"){
  const u=authorized(req,res,["landlord"]);if(!u)return;
  return json(res,200,{tenants:tenants.filter(t=>u.propertyIds.includes(t.propertyId)).map(t=>({...t,connectionId:t.connectionId}))});
 }
 if(req.method==="POST" && url.pathname==="/api/tenants"){
  const u=authorized(req,res,["landlord"]);if(!u)return;
  try{const d=await body(req);const name=String(d.name||"").trim(),email=String(d.email||"").trim().toLowerCase(),phone=String(d.phone||"").trim(),meterNumber=String(d.meterNumber||"").trim(),propertyId=String(d.propertyId||""),startMonth=String(d.startMonth||"");
   if(!name||!email.includes("@")||!phone||!meterNumber||!startMonth.match(/^\d{4}-(0[1-9]|1[0-2])$/))return fail(res,400,"Enter tenant name, valid email, phone, meter number, and starting month.");
   if(!u.propertyIds.includes(propertyId))return fail(res,403,"You can only assign tenants to your own properties.");
   if(users.some(x=>x.email.toLowerCase()===email)||tenants.some(x=>x.meterNumber===meterNumber))return fail(res,409,"That email or meter number is already registered.");
   const connectionId=`c-${crypto.randomUUID().slice(0,8)}`;const id=`ten-${crypto.randomUUID().slice(0,8)}`;
   const t={id,name,email,phone,meterNumber,propertyId,connectionId,startMonth,moveInDate:String(d.moveInDate||`${startMonth}-01`),landlordId:u.id};tenants.push(t);
   // Seed a clearly synthetic monthly history for the newly assigned meter; tenant filtering hides all periods before startMonth.
   const template=bills.find(b=>b.propertyId===propertyId)||bills[0];
   for(let month=1;month<=10;month++){const mm=String(month).padStart(2,"0"),period=`${["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct"][month-1]} 2026`;const units=70+month*9;const prev=500+(month-1)*units;const current=prev+units;const clone={...template,id:`b-${crypto.randomUUID().slice(0,8)}`,connectionId,propertyId,period,dueDate:`2026-${mm}-28`,previousReading:prev,estimatedReadings:month===9?[prev+Math.round(units*.55)]:[],currentReading:current,readingType:month===9?"actual":"actual",fixedCharge:template.fixedCharge, taxRate:template.taxRate,arrears:0,adjustments:0,status:"unpaid",tenantVisible:true};clone.amountDue=calculateBill(clone).total;bills.push(clone);}
   users.push({id:`u-${crypto.randomUUID().slice(0,8)}`,email,password:"Tenant@123",name,role:"tenant",propertyIds:[propertyId],connectionIds:[connectionId],tenancyId:id});
   log(u,"ADD_TENANT",id);return json(res,201,{tenant:t,temporaryPassword:"Tenant@123",notice:"Tenant created. This demo account uses a temporary demo password; no email was sent."});
  }catch{return fail(res,400,"Invalid tenant details.");}
 }
 if(req.method==="GET" && url.pathname==="/api/bills"){
  const u=authorized(req,res); if(!u)return;
  log(u,"LIST_BILLS","scoped"); return json(res,200,{bills:userBills(u).map(safeBill)});
 }
 if(req.method==="GET" && url.pathname==="/api/payments"){
  const u=authorized(req,res); if(!u)return;
  return json(res,200,{payments:userPayments(u)});
 }
 if(req.method==="POST" && url.pathname==="/api/payments/initiate"){
  const u=authorized(req,res,["tenant","landlord"]);if(!u)return;
  try{const d=await body(req);const bill=userBills(u).find(b=>b.id===d.billId);if(!bill)return fail(res,404,"Bill is not available to this account.");
   const active=payments.find(p=>p.billId===bill.id && ["initiated","pending","debit_confirmed"].includes(p.status));
   if(active)return json(res,409,{error:"A payment attempt is already unresolved. Do not pay again until it is reconciled.",payment:active,duplicateGuard:true});
   if(bill.status==="paid")return fail(res,409,"This bill is already marked paid.");
   const p={id:`pay-${crypto.randomUUID().slice(0,8)}`,billId:bill.id,connectionId:bill.connectionId,amount:bill.amountDue,status:"initiated",attempts:1,reference:`DEMO-${crypto.randomBytes(4).toString("hex").toUpperCase()}`,createdAt:new Date().toISOString(),providerConfirmed:false,provider:"SIMULATED_CHECKOUT"};payments.unshift(p);p.status="pending";log(u,"SIMULATED_PAYMENT_INITIATED",bill.id);return json(res,201,{payment:p,notice:"SIMULATED checkout only. No money was moved and no bank/provider was contacted."});
  }catch{return fail(res,400,"Invalid payment request.");}
 }
 if(req.method==="POST" && url.pathname.startsWith("/api/payments/") && url.pathname.endsWith("/simulate-result")){
  const u=authorized(req,res,["tenant","landlord"]);if(!u)return;const id=url.pathname.split("/")[3];const p=payments.find(x=>x.id===id);if(!p||!userBills(u).some(b=>b.id===p.billId))return fail(res,404,"Payment not found in your permitted scope.");
  try{const d=await body(req);const result=["debit_confirmed","failed","reversed","credit_reconciled"].includes(d.result)?d.result:"debit_confirmed";p.status=result;p.providerConfirmed=result==="credit_reconciled";p.demoNote="User-selected simulated result; not a real provider response.";if(result==="credit_reconciled"){const b=bills.find(x=>x.id===p.billId);if(b)b.status="paid";}log(u,"SIMULATED_PAYMENT_RESULT",p.id);return json(res,200,{payment:p,notice:"This result is simulated only; no actual payment was processed."});}catch{return fail(res,400,"Invalid simulated result.");}
 }
 if(req.method==="POST" && url.pathname.startsWith("/api/payments/") && url.pathname.endsWith("/reconcile")){
  const u=authorized(req,res,["staff"]); if(!u)return;
  if(u.staffRole!=="billing_admin" && u.staffRole!=="support_staff"){log(u,"DENY_RECONCILE","payment",false);return fail(res,403,"Only billing or support staff can reconcile payments.");}
  const id=url.pathname.split("/")[3]; const p=payments.find(x=>x.id===id); if(!p)return fail(res,404,"Payment not found.");
  p.status="credit_reconciled";p.providerConfirmed=false;p.demoNote="SIMULATED staff reconciliation; no provider was contacted.";
  log(u,"SIMULATED_RECONCILE",id); return json(res,200,{payment:p,notice:"SIMULATED only — no real provider response was received."});
 }
 if(req.method==="GET" && url.pathname==="/api/outages"){
  const u=authorized(req,res); if(!u)return; return json(res,200,{outages:userOutages().map(o=>({...o}))});
 }
 if(req.method==="POST" && url.pathname==="/api/outages/report"){
  const u=authorized(req,res); if(!u)return;
  try{const d=await body(req); if(!String(d.area||"").trim())return fail(res,400,"Area is required.");
   const o={id:"out-"+crypto.randomUUID().slice(0,8),title:`Community report — ${String(d.area).slice(0,80)}`,area:String(d.area).slice(0,120),feeder:"Unknown",transformer:"Unknown",reports:1,status:"reported",kind:"unknown",etaMin:"Not available",updatedAt:new Date().toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"}),message:"User-reported and not yet verified."};
   outages.unshift(o);log(u,"REPORT_OUTAGE",o.id);return json(res,201,{outage:o});
  }catch{return fail(res,400,"Invalid report.");}
 }
 if(req.method==="POST" && url.pathname.startsWith("/api/outages/") && url.pathname.endsWith("/verify")){
  const u=authorized(req,res,["staff"]); if(!u)return;
  if(u.staffRole!=="outage_operator" && u.staffRole!=="access_admin"){return fail(res,403,"Only outage operators can verify outage clusters.");}
  try{const d=await body(req);const id=url.pathname.split("/")[3];const o=outages.find(x=>x.id===id);if(!o)return fail(res,404,"Outage not found.");
   const kind=["fault","planned_maintenance","resolved","unknown"].includes(d.kind)?d.kind:"unknown";
   o.kind=kind;o.status=kind==="unknown"?"reported":"verified";o.etaMin=String(d.etaMin||"Not available").slice(0,60);o.updatedAt=new Date().toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit"});
   o.message=kind==="planned_maintenance"?"Verified planned maintenance. Earlier fault assumptions have been corrected.":kind==="fault"?"Fault verified by an authorized demo operator; ETA is an estimate.":kind==="resolved"?"Marked resolved in the simulated workflow.":"Status remains unverified.";
   log(u,"VERIFY_OUTAGE",id);return json(res,200,{outage:o});
  }catch{return fail(res,400,"Invalid update.");}
 }
 if(req.method==="POST" && url.pathname==="/api/assistant"){
  const u=authorized(req,res); if(!u)return;
  try{const d=await body(req);const prompt=String(d.message||"").slice(0,1200);if(!prompt.trim())return fail(res,400,"Enter a question.");
   const permitted={user:publicUser(u),bills:userBills(u).map(safeBill),payments:userPayments(u),outages:outages.map(o=>({...o}))};
   const answer=assistantReply(prompt,permitted);log(u,"ASSISTANT_QUERY","role-scoped");return json(res,200,{answer,mode:"RULE_BASED_DEMO",language:"en"});
  }catch{return fail(res,400,"Could not process the question.");}
 }
 if(req.method==="GET" && url.pathname==="/api/audit"){
  const u=authorized(req,res,["staff"]);if(!u)return;return json(res,200,{audit:audit.slice(0,100)});
 }
 if(url.pathname.startsWith("/api/"))return fail(res,404,"API route not found.");
 let pathname=decodeURIComponent(url.pathname);if(pathname==="/")pathname="/index.html";
 const file=path.join(__dirname,"public",pathname);
 if(!file.startsWith(path.join(__dirname,"public")))return fail(res,403,"Forbidden.");
 fs.readFile(file,(err,data)=>{if(err)return fail(res,404,"Page not found.");res.writeHead(200,{"Content-Type":mime[path.extname(file)]||"application/octet-stream","X-Content-Type-Options":"nosniff","Referrer-Policy":"same-origin","X-Frame-Options":"DENY"});res.end(data);});
});
app.listen(PORT,()=>console.log(`UtilityCare AI v1 running at http://localhost:${PORT}`));
